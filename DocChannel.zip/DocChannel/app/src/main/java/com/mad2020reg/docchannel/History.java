package com.mad2020reg.docchannel;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.PixelCopy;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.mad2020reg.docchannel.Database.DBHelper;

import java.util.Calendar;
import java.util.List;

public class History extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);




        /****Question 09  ****/





    }
}